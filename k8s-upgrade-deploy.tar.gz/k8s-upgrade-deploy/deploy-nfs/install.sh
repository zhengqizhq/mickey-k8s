#!/bin/bash

NFS_IP=$1

kubectl label node $NFS_IP nfsServer=true

kubectl create -f ~/k8s-upgrade-deploy/deploy-nfs/nfs-server-pv.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-nfs/nfs-server-pvc.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-nfs/nfs-server-rc.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-nfs/nfs-server-service.yaml

sed -i "s/.*server.*/          server: $NFS_IP/" ~/k8s-upgrade-deploy/deploy-nfs/nfs-pv-rc.yaml
sed -i "s/.*ip.*/  ip: $NFS_IP/" ~/k8s-upgrade-deploy/deploy-nfs/volumnprovider.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-nfs/nfs-pv-rc.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-nfs/thirdPartyResource.yaml
sleep 5
kubectl create -f ~/k8s-upgrade-deploy/deploy-nfs/volumnprovider.yaml
