#!/bin/bash

while true 
do 
    pv=$(kubectl get pv --kubeconfig=/opt/kubelet.conf | awk '{print $1}')
    pvList=($pv)
    echo ${#pvList[@]}
    pvLen=${#pvList[@]}
    #echo $pvLen
    inputDir=/tony
    for ((i=1;i<$pvLen;i++))
    do
       pvName=${pvList[$i]}
       echo $pvName
       pvStatus=false
       for file_nfs in ${inputDir}/*
       do   
	    temp_file=`basename $file_nfs`
            if [ $temp_file == $pvName ]
 	    then 
               pvStatus=true
               break
            fi
       done 
       if [ $pvStatus == false ] 
       then
          cd $inputDir
          mkdir $pvName 
       fi
    done
    for file_nfs in ${inputDir}/* 
    do  
    	temp_file=`basename $file_nfs`
        nfsStatus=false  
    	for ((i=1;i<$pvLen;i=i+1))
	do
	    pvName=${pvList[$i]}
	    if [ $temp_file == $pvName ]
 	    then
	       nfsStatus=true
               break;
            fi 
	done
        if [ $nfsStatus == false ]
	then
          cd $inputDir
          rm -rf $temp_file  
        fi
    done  
    sleep 8
done
