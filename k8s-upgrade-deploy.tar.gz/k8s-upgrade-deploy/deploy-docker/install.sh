#!/bin/bash

REQISTRY=$1
bashpath=$(cd `dirname $0`; pwd)


setenforce 0
sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config


#mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.bk
#wget http://mirrors.163.com/.help/CentOS6-Base-163.repo -P /etc/yum.repos.d/
#yum makecache


#yum -y install docker
rpm -ivh $bashpath/centos7-2/*.rpm --nodeps --force

#echo "ADD_REGISTRY='--add-registry $REQISTRY'" >> /etc/sysconfig/docker
#echo "INSECURE_REGISTRY='--insecure-registry=$REQISTRY'" >> /etc/sysconfig/docker

sed -i "s/.*ADD_REGISTRY=.*/ADD_REGISTRY='--add-registry $REQISTRY'/" /etc/sysconfig/docker
sed -i "s/.*INSECURE_REGISTRY=.*/INSECURE_REGISTRY='--insecure-registry=$REQISTRY'/" /etc/sysconfig/docker
sed -i "s|.*OPTIONS.*|OPTIONS='--selinux-enabled --log-driver=journald --signature-verification=false --registry-mirror=http://$REQISTRY'|" /etc/sysconfig/docker

systemctl enable docker && systemctl restart docker
