#!/bin/bash


bashpath=$(cd `dirname $0`; pwd)

echo "bashpath:"$bashpath

FTP_SERVER=10.10.103.117

curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/audit-2.6.5-3.el7_3.1.x86_64.rpm -o $bashpath/centos7-2/audit-2.6.5-3.el7_3.1.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/audit-libs-2.6.5-3.el7_3.1.x86_64.rpm -o $bashpath/centos7-2/audit-libs-2.6.5-3.el7_3.1.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/audit-libs-python-2.6.5-3.el7_3.1.x86_64.rpm -o $bashpath/centos7-2/audit-libs-python-2.6.5-3.el7_3.1.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/checkpolicy-2.5-4.el7.x86_64.rpm -o $bashpath/centos7-2/checkpolicy-2.5-4.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/container-selinux-2.9-4.el7.noarch.rpm -o $bashpath/centos7-2/container-selinux-2.9-4.el7.noarch.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/device-mapper-1.02.135-1.el7_3.3.x86_64.rpm -o $bashpath/centos7-2/device-mapper-1.02.135-1.el7_3.3.x86_64.rpm

curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/device-mapper-event-1.02.135-1.el7_3.3.x86_64.rpm -o $bashpath/centos7-2/device-mapper-event-1.02.135-1.el7_3.3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/device-mapper-event-libs-1.02.135-1.el7_3.3.x86_64.rpm -o $bashpath/centos7-2/device-mapper-event-libs-1.02.135-1.el7_3.3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/device-mapper-libs-1.02.135-1.el7_3.3.x86_64.rpm -o $bashpath/centos7-2/device-mapper-libs-1.02.135-1.el7_3.3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/device-mapper-persistent-data-0.6.3-1.el7.x86_64.rpm -o $bashpath/centos7-2/device-mapper-persistent-data-0.6.3-1.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/docker-1.12.6-11.el7.centos.x86_64.rpm -o $bashpath/centos7-2/docker-1.12.6-11.el7.centos.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/docker-client-1.12.6-11.el7.centos.x86_64.rpm -o $bashpath/centos7-2/docker-client-1.12.6-11.el7.centos.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/docker-common-1.12.6-11.el7.centos.x86_64.rpm -o $bashpath/centos7-2/docker-common-1.12.6-11.el7.centos.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/dracut-033-463.el7.x86_64.rpm -o $bashpath/centos7-2/dracut-033-463.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/dracut-config-rescue-033-463.el7.x86_64.rpm -o $bashpath/centos7-2/dracut-config-rescue-033-463.el7.x86_64.rpm


curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/dracut-network-033-463.el7.x86_64.rpm -o $bashpath/centos7-2/dracut-network-033-463.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/glib2-2.46.2-4.el7.x86_64.rpm -o $bashpath/centos7-2/glib2-2.46.2-4.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/initscripts-9.49.37-1.el7.x86_64.rpm -o $bashpath/centos7-2/initscripts-9.49.37-1.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/kmod-20-9.el7.x86_64.rpm -o $bashpath/centos7-2/kmod-20-9.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libaio-0.3.109-13.el7.x86_64.rpm -o $bashpath/centos7-2/libaio-0.3.109-13.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libcgroup-0.41-11.el7.x86_64.rpm -o $bashpath/centos7-2/libcgroup-0.41-11.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libgudev1-219-30.el7_3.7.x86_64.rpm -o $bashpath/centos7-2/libgudev1-219-30.el7_3.7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libseccomp-2.3.1-2.el7.x86_64.rpm -o $bashpath/centos7-2/libseccomp-2.3.1-2.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libselinux-2.5-6.el7.x86_64.rpm -o $bashpath/centos7-2/libselinux-2.5-6.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libselinux-python-2.5-6.el7.x86_64.rpm -o $bashpath/centos7-2/libselinux-python-2.5-6.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libselinux-utils-2.5-6.el7.x86_64.rpm -o $bashpath/centos7-2/libselinux-utils-2.5-6.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libsemanage-2.5-5.1.el7_3.x86_64.rpm -o $bashpath/centos7-2/libsemanage-2.5-5.1.el7_3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libsemanage-python-2.5-5.1.el7_3.x86_64.rpm -o $bashpath/centos7-2/libsemanage-python-2.5-5.1.el7_3.x86_64.rpm

curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/libsepol-2.5-6.el7.x86_64.rpm -o $bashpath/centos7-2/libsepol-2.5-6.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/lvm2-2.02.166-1.el7_3.3.x86_64.rpm -o $bashpath/centos7-2/lvm2-2.02.166-1.el7_3.3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/lvm2-libs-2.02.166-1.el7_3.3.x86_64.rpm -o $bashpath/centos7-2/lvm2-libs-2.02.166-1.el7_3.3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/oci-register-machine-0-1.11.gitdd0daef.el7.x86_64.rpm -o $bashpath/centos7-2/oci-register-machine-0-1.11.gitdd0daef.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/oci-systemd-hook-0.1.4-9.git671c428.el7.x86_64.rpm -o $bashpath/centos7-2/oci-systemd-hook-0.1.4-9.git671c428.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/policycoreutils-2.5-11.el7_3.x86_64.rpm -o $bashpath/centos7-2/policycoreutils-2.5-11.el7_3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/policycoreutils-python-2.5-11.el7_3.x86_64.rpm -o $bashpath/centos7-2/policycoreutils-python-2.5-11.el7_3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/python-IPy-0.75-6.el7.noarch.rpm -o $bashpath/centos7-2/python-IPy-0.75-6.el7.noarch.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/selinux-policy-3.13.1-102.el7_3.15.noarch.rpm -o $bashpath/centos7-2/selinux-policy-3.13.1-102.el7_3.15.noarch.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/selinux-policy-targeted-3.13.1-102.el7_3.15.noarch.rpm -o $bashpath/centos7-2/selinux-policy-targeted-3.13.1-102.el7_3.15.noarch.rpm

curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/setools-libs-3.3.8-1.1.el7.x86_64.rpm -o $bashpath/centos7-2/setools-libs-3.3.8-1.1.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/skopeo-containers-0.1.18-1.el7.x86_64.rpm -o $bashpath/centos7-2/skopeo-containers-0.1.18-1.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/systemd-219-30.el7_3.7.x86_64.rpm -o $bashpath/centos7-2/systemd-219-30.el7_3.7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/systemd-libs-219-30.el7_3.7.x86_64.rpm -o $bashpath/centos7-2/systemd-libs-219-30.el7_3.7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/systemd-sysv-219-30.el7_3.7.x86_64.rpm -o $bashpath/centos7-2/systemd-sysv-219-30.el7_3.7.x86_64.rpm

curl -L  http://${FTP_SERVER}/k8s-1-5-3/docker-centos-7-2/yajl-2.0.4-4.el7.x86_64.rpm -o $bashpath/centos7-2/yajl-2.0.4-4.el7.x86_64.rpm