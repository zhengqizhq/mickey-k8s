#!/bin/bash

LOG_IP=$1
NODE_IPS=$2

IFS=',' arr=($NODE_IPS)
for ip in ${arr[@]}; do
    kubectl label node $ip alpha.kubernetes.io/fluentd-ds-ready=true
done

kubectl label node $LOG_IP nodeType=log
kubectl create -f ~/k8s-upgrade-deploy/deploy-log/es-rc.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-log/es-service.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-log/fluentd-daemonset.yaml
