#!/bin/bash

MONITOR_IP=$1

kubectl label node $MONITOR_IP monitor=true
kubectl create -f ~/k8s-upgrade-deploy/deploy-monitor/influxdb-deployment.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-monitor/influxdb-service.yaml

kubectl create -f ~/k8s-upgrade-deploy/deploy-monitor/heapster-deployment.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-monitor/heapster-service.yaml
