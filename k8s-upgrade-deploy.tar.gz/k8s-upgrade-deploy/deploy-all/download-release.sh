#!/bin/bash

./../deploy-docker/download-release.sh
./../deploy-k8s/download-release.sh
