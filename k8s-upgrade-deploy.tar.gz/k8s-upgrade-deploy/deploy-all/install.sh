#!/bin/bash

k8s_master_ip=""
k8s_ips=""
k8s_node_ips=""
log_ip=""
monitor_ip=""
mysql_ip=""
harbor_ip=""
nfs_ip=""
haproxy_ip=''
dns_domain=""
bind9_ip=""

    k8s_allipstr=""
    k8s_masterstr=""
    k8s_node_ipstr=""
    k8s_node_userstr=""
    k8s_node_passwordstr=""
    k8s_ipstr=""

    cat config.json | ./jq . &> /dev/null 
    if [ $? -ne 0 ]
    then
    echo "Josn format error in the config.json!"
    cat config.json | ./jq .
    exit 1 
    fi

    k8s_ips_array=(`cat config.json | ./jq '.k8s_nodes[] | .ip'`)
    k8s_users_array=(`cat config.json | ./jq '.k8s_nodes[] | .user'`)
    k8s_passwords_array=(`cat config.json | ./jq '.k8s_nodes[] | .password'`)
    k8s_roles_array=(`cat config.json | ./jq '.k8s_nodes[] | .role'`)
    harbor_ip=`cat config.json | ./jq -r '.harbor_ip'`
    dns_domain=`cat config.json | ./jq -r '.dns_domain'`
    sys_version=`cat config.json | ./jq -r '.sys_version'`

    for (( c=0; c<${#k8s_ips_array[@]}; c++ )); do
      if [ ${k8s_roles_array[c]} == \""master"\" ]
      then
        k8s_master_ip=${k8s_ips_array[c]}
      elif [ ${k8s_roles_array[c]} == \""slave"\" ]
      then
        k8s_node_ipstr=$k8s_node_ipstr${k8s_ips_array[c]}","
        k8s_node_userstr=$k8s_node_userstr${k8s_users_array[c]}","
        k8s_node_passwordstr=$k8s_node_passwordstr${k8s_passwords_array[c]}","
      fi
      k8s_ipstr=$k8s_ipstr${k8s_ips_array[c]}","
    done

    k8s_ips=${k8s_ipstr%?}
    k8s_node_ips=${k8s_node_ipstr%?}
    k8s_node_users=${k8s_node_userstr%?}
    k8s_node_passwords=${k8s_node_passwordstr%?}

    k8s_ips=`echo $k8s_ips | sed 's/\"//g'`
    k8s_node_ips=`echo $k8s_node_ips | sed 's/\"//g'`
    k8s_node_users=`echo $k8s_node_users | sed 's/\"//g'`
    k8s_node_passwords=`echo $k8s_node_passwords | sed 's/\"//g'`
    k8s_master_ip=`echo $k8s_master_ip | sed 's/\"//g'`

    #echo $k8s_node_ips

    arr=(${k8s_node_ips//,/ })
    #IFS=',' arr=($k8s_node_ips)
    #for ((i=0;i<${#arr[*]};i++)); do
    for ((i=0;i<${#arr[@]};i++)); do
        if [ ! $log_ip ]
        then
          log_ip=${arr[$i]}
           if [[ ${#arr[*]} == $((i+1)) ]]
          then
             i=-1
          fi
          continue
        fi
        if [ ! $monitor_ip ]
        then
          monitor_ip=${arr[$i]}
          if [[ ${#arr[*]} == $((i+1)) ]]
          then
             i=-1
          fi
          continue
        fi
        if [ ! $mysql_ip ]
        then
          mysql_ip=${arr[$i]}
          if [[ ${#arr[*]} == $((i+1)) ]]
          then
             i=-1
          fi
          continue
        fi
        if [ ! $nfs_ip ]
        then
          nfs_ip=${arr[$i]}
          if [[ ${#arr[*]} == $((i+1)) ]]
          then
             i=-1
          fi
          continue
        fi
        if [ ! $haproxy_ip ]
        then
          haproxy_ip=${arr[$i]}
          if [[ ${#arr[*]} == $((i+1)) ]]
          then
             i=-1
          fi
          continue
        fi
        if [ ! $bind9_ip ]
        then
          bind9_ip=${arr[$i]}
          if [[ ${#arr[*]} == $((i+1)) ]]
          then
             i=-1
          fi
          continue
        fi
    done


function execShell()
{
  echo ""
  echo $echoStr
  echo "Running ..."
  echo "" >>  /var/log/deploy.log
  echo $echoStr >>  /var/log/deploy.log
  echo $shellStr >>  /var/log/deploy.log
  eval $shellStr
  if [ $? -ne 0 ]
  then
    echo "Shell 命令执行失败."
  fi

  echo "End"

}


#选择菜单
echo "0 终止部署"
#echo "99 一键部署"
echo "1 部署k8s master节点"
echo "2 部署k8s node节点"
echo "3 部署网络"
echo "4 部署日志"
echo "5 部署监控"
echo "6 部署运维后台(webhook logapi monitorapi)"
echo "7 部署UI"
echo "8 部署haproxy"
echo "9 部署bind9"
echo "10 部署nfs"

while [[ 1 == 1 ]]
do
echo -n "输入您要部署的模块编号:"
read num

#清空日志
if [ $num != "0" ]
then
echo "" > /var/log/deploy.log
fi

if [ $num == "0" ]
then
  exit 0
fi

#echo -n "请确认是安装or卸载？ [I/U]:"
echo -n "请确认安装？ [Y/n]:"
read iu

if [[ $iu == "Y" ]] || [[ $iu == "y" ]]
then
  if [[ $num == "99" ]]
    then
      echoStr="99 一键部署"
      echo $echoStr >> /var/log/deploy.log
  fi

  if [[ $num == "99" ]] || [[ $num == "1" ]]
  then
      echoStr="1 部署k8s master节点"
      shellStr="./../deploy-k8s/install-master.sh $harbor_ip $k8s_master_ip $sys_version >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
  fi

  if [[ $num == "99" ]] || [[ $num == "2" ]]
  then
      arr_user=(${k8s_node_users//,/ })
      arr_password=(${k8s_node_passwords//,/ })
      arr=(${k8s_node_ips//,/ })
      #IFS=',' arr_user=($k8s_node_users)
      #IFS=',' arr_password=($k8s_node_passwords)
      #IFS=',' arr=($k8s_node_ips)
      #for ((i=0;i<${#arr[*]};i++)); do
      for ((i=0;i<${#arr[@]};i++)); do
        echoStr="2 部署k8s node节点---"${arr[$i]}
        shellStr="./../deploy-k8s/install-node.sh ${arr[$i]} ${arr_user[$i]} ${arr_password[$i]} $harbor_ip $k8s_master_ip $sys_version >> /var/log/deploy.log"
        execShell $echoStr $shellStr $num
      done

  fi

  if [[ $num == "99" ]] || [[ $num == "3" ]]
  then
      echoStr="3 部署网络"
      shellStr="./../deploy-calico/install.sh >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
  fi

  if [[ $num == "99" ]] || [[ $num == "4" ]]
  then
      echoStr="4 部署日志"
      shellStr="./../deploy-log/install.sh $log_ip $k8s_ips >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
  fi

  if [[ $num == "99" ]] || [[ $num == "5" ]]
  then
      echoStr="5 部署监控"
      shellStr="./../deploy-monitor/install.sh $monitor_ip >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
  fi

  if [[ $num == "99" ]] || [[ $num == "6" ]]
  then
      echoStr="6 部署运维后台(webhook logapi monitorapi)"
      shellStr="./../deploy-webhook-logapi-monitorapi/install.sh $mysql_ip $harbor_ip >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
  fi

  if [[ $num == "99" ]] || [[ $num == "7" ]]
  then
      echoStr="7 部署UI"
      shellStr="./../deploy-nephele/install.sh $harbor_ip $k8s_master_ip $nfs_ip $dns_domain >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
      kubectl delete job configure-calico --namespace=kube-system
  fi

  if [[ $num == "99" ]] || [[ $num == "8" ]]
  then
      echoStr="8 部署haproxy"
      shellStr="./../deploy-haproxy/install.sh $haproxy_ip >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
  fi

  if [[ $num == "99" ]] || [[ $num == "9" ]]
  then
      echoStr="9 部署bind9"
      shellStr="./../deploy-bind9/install.sh $dns_domain $haproxy_ip $bind9_ip >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num
  fi

  if [[ $num == "99" ]] || [[ $num == "10" ]]
  then
      echoStr="10 部署nfs"
      shellStr="./../deploy-nfs/install.sh $nfs_ip >> /var/log/deploy.log"
      execShell $echoStr $shellStr $num


  fi



fi

done


