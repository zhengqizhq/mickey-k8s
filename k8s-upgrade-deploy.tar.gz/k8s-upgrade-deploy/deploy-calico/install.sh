#!/bin/bash

kubectl create -f ~/k8s-upgrade-deploy/deploy-calico/calico.yaml

kubectl delete deployment kube-dns --namespace=kube-system
kubectl create -f ~/k8s-upgrade-deploy/deploy-calico/kubedns-deployment.yaml
