k8s-upgrade-deploy项目说明

#1.项目用于自动化部署观云台项目，支持kubernentes1.5以上
#2.项目只维护部署相关的脚本，yaml文件，build image文件
#3.项目中涉及的大文件，附件，jar包不进行维护，统一上传到10.10.103.117:/var/www/html/k8s-1-5-1目录下，通过wget http://10.10.103.117/k8s-1-5-1/filename 下载
   eg: ./download-release.sh