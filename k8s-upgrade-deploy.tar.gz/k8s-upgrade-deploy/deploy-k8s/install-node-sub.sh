#!/bin/bash

REQISTRY=$1
MASTER_IP=$2

#if [ $SYS_VERSION == "centos7.2" ]
#then
    rpm -ivh ~/deploy-docker/centos7-2/*.rpm --nodeps --force
    rpm -ivh ~/deploy-k8s/files/socat-1.7.2.2-5.el7.x86_64.rpm --nodeps --force
    rpm -ivh ~/deploy-k8s/files/ebtables-2.0.10-15.el7.x86_64.rpm --nodeps --force
    rpm -ivh ~/deploy-k8s/files/tcl-8.5.13-8.el7.x86_64.rpm --nodeps --force
    rpm -ivh ~/deploy-k8s/files/expect-5.45-14.el7_1.x86_64.rpm --nodeps --force
    rpm -ivh ~/deploy-k8s/files/nfs-utils-centos7-2/*.rpm --nodeps --force

#fi

#if [ $SYS_VERSION == "redhat7.2" ]
#then
#    rpm -ivh ~/k8s-upgrade-deploy/deploy-docker/centos7-2/*.rpm --nodeps --force
#    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/socat-1.7.2.2-5.el7.x86_64.rpm --nodeps --force
#    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/ebtables-2.0.10-15.el7.x86_64.rpm --nodeps --force
#    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/tcl-8.5.13-8.el7.x86_64.rpm --nodeps --force
#    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/expect-5.45-14.el7_1.x86_64.rpm --nodeps --force
#    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/nfs-utils-centos7-2/*.rpm --nodeps --force
#fi


setenforce 0
sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config

#echo "ADD_REGISTRY='--add-registry $REQISTRY'" >> /etc/sysconfig/docker
#echo "INSECURE_REGISTRY='--insecure-registry=$REQISTRY'" >> /etc/sysconfig/docker
sed -i "s/.*ADD_REGISTRY=.*/ADD_REGISTRY='--add-registry $REQISTRY'/" /etc/sysconfig/docker 
sed -i "s/.*INSECURE_REGISTRY=.*/INSECURE_REGISTRY='--insecure-registry=$REQISTRY'/" /etc/sysconfig/docker 
sed -i "s|.*OPTIONS.*|OPTIONS='--selinux-enabled --log-driver=journald --signature-verification=false --registry-mirror=http://$REQISTRY'|" /etc/sysconfig/docker

systemctl enable docker && systemctl restart docker
systemctl stop firewalld.service
systemctl disable firewalld.service

images=(kube-proxy-amd64:v1.5.3 kubedns-amd64:1.9 kube-dnsmasq-amd64:1.4 dnsmasq-metrics-amd64:1.0 exechealthz-amd64:1.2 pause-amd64:3.0)
for imageName in ${images[@]} ; do
  docker pull k8s-deploy/$imageName
  docker tag k8s-deploy/$imageName gcr.io/google_containers/$imageName
  docker rmi k8s-deploy/$imageName
done

sudo rpm -qa | grep kubelet &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubelet &> /dev/null
fi

sudo rpm -qa | grep kubeadm &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubeadm &> /dev/null
fi

sudo rpm -qa | grep kubectl &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubectl &> /dev/null
fi

sudo rpm -qa | grep kubernetes-cni &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubernetes-cni &> /dev/null
fi

rpm -ivh ~/deploy-k8s/files/kubeadm.rpm ~/deploy-k8s/files/kubectl.rpm ~/deploy-k8s/files/kubelet.rpm ~/deploy-k8s/files/cni.rpm

systemctl stop kubelet
cp -r ~/deploy-k8s/files/kubelet /usr/bin/kubelet

systemctl enable kubelet && systemctl restart kubelet

kubeadm reset
if [ -e /var/lib/etcd ]
then
  rm -rf /var/lib/etcd
fi

kubeadm join $MASTER_IP --token=8358ba.70fdd01e8e5eb18b


