#!/bin/bash

IP=$1
USER=$2
PASSWORD=$3
HARBOR_IP=$4
K8S_MASTER_IP=$5
#SYS_VERSION=$6

#bashpath=$(cd `dirname $0` pwd;)
    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/tcl-8.5.13-8.el7.x86_64.rpm --nodeps --force
    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/expect-5.45-14.el7_1.x86_64.rpm --nodeps --force

/usr/bin/expect ~/k8s-upgrade-deploy/deploy-k8s/scp-k8s.exp $IP $USER $PASSWORD
/usr/bin/expect ~/k8s-upgrade-deploy/deploy-k8s/ssh-deploy-k8s-node.exp $IP $USER $PASSWORD $HARBOR_IP $K8S_MASTER_IP
