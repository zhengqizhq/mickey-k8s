#!/bin/bash

REQISTRY=$1
K8S_MASTER_IP=$2
SYS_VERSION=$3

bashpath=$(cd `dirname $0` pwd;)

setenforce 0
sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config


#mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.bk
#wget http://mirrors.163.com/.help/CentOS6-Base-163.repo -P /etc/yum.repos.d/
#yum makecache

#if [ $SYS_VERSION == "centos7.2" ]
#then
    #yum -y install docker
    #yum install -y socat
    #yum install -y ebtables
    #yum install -y nfs-utils
    rpm -ivh ~/k8s-upgrade-deploy/deploy-docker/centos7-2/*.rpm --nodeps --force
    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/socat-1.7.2.2-5.el7.x86_64.rpm --nodeps --force
    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/ebtables-2.0.10-15.el7.x86_64.rpm --nodeps --force
    rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/nfs-utils-centos7-2/*.rpm --nodeps --force


#fi

#if [ $SYS_VERSION == "redhat7.2" ]
#then
 #   rpm -ivh $bashpath/../deploy-docker/centos7-2/*.rpm --nodeps --force
  #  rpm -ivh $bashpath/files/socat-1.7.2.2-5.el7.x86_64.rpm --nodeps --force
   # rpm -ivh $bashpath/files/ebtables-2.0.10-15.el7.x86_64.rpm --nodeps --force
    #rpm -ivh $bashpath/files/nfs-utils-centos7-2/*.rpm --nodeps --force
#fi



#echo "ADD_REGISTRY='--add-registry $REQISTRY'" >> /etc/sysconfig/docker
#echo "INSECURE_REGISTRY='--insecure-registry=$REQISTRY'" >> /etc/sysconfig/docker

sed -i "s/.*ADD_REGISTRY=.*/ADD_REGISTRY='--add-registry $REQISTRY'/" /etc/sysconfig/docker
sed -i "s/.*INSECURE_REGISTRY=.*/INSECURE_REGISTRY='--insecure-registry=$REQISTRY'/" /etc/sysconfig/docker
sed -i "s|.*OPTIONS.*|OPTIONS='--selinux-enabled --log-driver=journald --signature-verification=false --registry-mirror=http://$REQISTRY'|" /etc/sysconfig/docker

systemctl enable docker && systemctl restart docker
systemctl stop firewalld.service
systemctl disable firewalld.service

images=(kube-apiserver-amd64:v1.5.3 kube-proxy-amd64:v1.5.3 kube-discovery-amd64:1.0 kubedns-amd64:1.9 kube-scheduler-amd64:v1.5.3 kube-controller-manager-amd64:v1.5.3 etcd-amd64:3.0.14-kubeadm kube-dnsmasq-amd64:1.4 dnsmasq-metrics-amd64:1.0 exechealthz-amd64:1.2 pause-amd64:3.0)
for imageName in ${images[@]} ; do
  docker pull k8s-deploy/$imageName
  docker tag k8s-deploy/$imageName gcr.io/google_containers/$imageName
  docker rmi k8s-deploy/$imageName
done

sudo rpm -qa | grep kubelet &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubelet &> /dev/null
fi

sudo rpm -qa | grep kubeadm &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubeadm &> /dev/null
fi

sudo rpm -qa | grep kubectl &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubectl &> /dev/null
fi

sudo rpm -qa | grep kubernetes-cni &> /dev/null
if [ $? -eq 0 ]
then
sudo yum remove -y kubernetes-cni &> /dev/null
fi

rpm -ivh ~/k8s-upgrade-deploy/deploy-k8s/files/kubeadm.rpm ~/k8s-upgrade-deploy/deploy-k8s/files/kubectl.rpm ~/k8s-upgrade-deploy/deploy-k8s/files/kubelet.rpm ~/k8s-upgrade-deploy/deploy-k8s/files/cni.rpm

systemctl stop kubelet
cp -rf ~/k8s-upgrade-deploy/deploy-k8s/files/kubelet /usr/bin/kubelet

systemctl enable kubelet && systemctl restart kubelet

kubeadm reset

if [ -e /var/lib/etcd ]
then
  rm -rf /var/lib/etcd 
fi
kubeadm init --use-kubernetes-version=v1.5.3 --token=8358ba.70fdd01e8e5eb18b

sleep 5

sed -i "s/.*--advertise-address.*/      --advertise-address=$K8S_MASTER_IP/" ~/k8s-upgrade-deploy/deploy-k8s/kube-apiserver.yaml
rm -rf /etc/kubernetes/manifests/kube-apiserver.json /etc/kubernetes/manifests/kube-controller-manager.json /etc/kubernetes/manifests/kube-scheduler.json

cp -rf ~/k8s-upgrade-deploy/deploy-k8s/kube-apiserver.yaml ~/k8s-upgrade-deploy/deploy-k8s/kube-controller-manager.yaml ~/k8s-upgrade-deploy/deploy-k8s/kube-scheduler.yaml /etc/kubernetes/manifests/

