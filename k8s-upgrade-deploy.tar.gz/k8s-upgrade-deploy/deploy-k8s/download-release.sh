#!/bin/bash

FTP_SERVER=10.10.103.117
bashpath=$(cd `dirname $0`; pwd)

curl -L  http://${FTP_SERVER}/k8s-1-5-1/kubeadm-1.6.0-0.alpha.0.2074.a092d8e0f95f52.x86_64.rpm -o $bashpath/files/kubeadm.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-1/kubectl-1.5.1-0.x86_64.rpm -o $bashpath/files/kubectl.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-1/kubelet-1.5.1-0.x86_64.rpm -o $bashpath/files/kubelet.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-1/kubernetes-cni-0.3.0.1-0.07a8a2.x86_64.rpm -o $bashpath/files/cni.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/kubelet -o $bashpath/files/kubelet

curl -L  http://${FTP_SERVER}/k8s-1-5-3/ebtables-2.0.10-15.el7.x86_64.rpm -o $bashpath/files/ebtables-2.0.10-15.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/expect-5.45-14.el7_1.x86_64.rpm -o $bashpath/files/expect-5.45-14.el7_1.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/socat-1.7.2.2-5.el7.x86_64.rpm -o $bashpath/files/socat-1.7.2.2-5.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/tcl-8.5.13-8.el7.x86_64.rpm -o $bashpath/files/tcl-8.5.13-8.el7.x86_64.rpm

curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/gssproxy-0.4.1-13.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/gssproxy-0.4.1-13.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/keyutils-1.5.8-3.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/keyutils-1.5.8-3.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libbasicobjects-0.1.1-27.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libbasicobjects-0.1.1-27.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libcollection-0.6.2-27.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libcollection-0.6.2-27.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libevent-2.0.21-4.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libevent-2.0.21-4.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libnfsidmap-0.25-15.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libnfsidmap-0.25-15.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libpath_utils-0.2.1-27.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libpath_utils-0.2.1-27.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libref_array-0.1.5-27.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libref_array-0.1.5-27.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libtalloc-2.1.6-1.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libtalloc-2.1.6-1.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libtevent-0.9.28-1.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libtevent-0.9.28-1.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libtirpc-0.2.4-0.8.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libtirpc-0.2.4-0.8.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/libverto-tevent-0.2.5-4.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/libverto-tevent-0.2.5-4.el7.x86_64.rpm

curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/nfs-utils-1.3.0-0.33.el7_3.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/nfs-utils-1.3.0-0.33.el7_3.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/quota-4.01-14.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/quota-4.01-14.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/quota-nls-4.01-14.el7.noarch.rpm -o $bashpath/files/nfs-utils-centos7-2/quota-nls-4.01-14.el7.noarch.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/rpcbind-0.2.0-38.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/rpcbind-0.2.0-38.el7.x86_64.rpm
curl -L  http://${FTP_SERVER}/k8s-1-5-3/nfs-utils-centos7-2/tcp_wrappers-7.6-77.el7.x86_64.rpm -o $bashpath/files/nfs-utils-centos7-2/tcp_wrappers-7.6-77.el7.x86_64.rpm


chmod +x $bashpath/files/kubelet
