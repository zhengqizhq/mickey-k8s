#!/bin/bash

HARBOR_IP=$1
K8S_MASTER_IP=$2
NFS_IP=$3
DNS_DOMAIN=$4

cp -r ~/k8s-upgrade-deploy/deploy-nephele/config.json.template ~/k8s-upgrade-deploy/deploy-nephele/config.json
sed -i "s/_HARBOR_IP/${HARBOR_IP}/g" ~/k8s-upgrade-deploy/deploy-nephele/config.json
sed -i "s/_K8S_MASTER_IP/${K8S_MASTER_IP}/g" ~/k8s-upgrade-deploy/deploy-nephele/config.json
sed -i "s/_NFS_IP/${NFS_IP}/g" ~/k8s-upgrade-deploy/deploy-nephele/config.json
sed -i "s/_DNS_DOMAIN/${DNS_DOMAIN}/g" ~/k8s-upgrade-deploy/deploy-nephele/config.json

kubectl create configmap nephele-config --from-file=../deploy-nephele/config.json --namespace=kube-system
kubectl create -f ~/k8s-upgrade-deploy/deploy-nephele/nephele-deployment.yaml --namespace=kube-system
kubectl create -f ~/k8s-upgrade-deploy/deploy-nephele/nephele-service.yaml --namespace=kube-system

