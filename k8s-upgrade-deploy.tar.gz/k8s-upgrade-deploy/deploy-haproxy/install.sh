#!/bin/bash

kubectl create -f ~/k8s-upgrade-deploy/deploy-haproxy/slb-rc.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-haproxy/slb-service.yaml
