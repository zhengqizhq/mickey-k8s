#!/bin/bash

set -ex

####################################
#                                 #
#          VARIABLES              #
#                                 #
###################################
COMPONENT=$1
DOCKERFILE=$1.Dockerfile
VERSION=$2
CURRENT_HOME=$(cd `dirname $0`; pwd)

####################################
#                                 #
#          FUNCTIONS              #
#                                 #
###################################
function init() {
   
   clean
   if [ -z "$VERSION" ];then
        VERSION="latest"
   fi
   mkdir $COMPONENT
   cp $CURRENT_HOME/$DOCKERFILE $CURRENT_HOME/$COMPONENT/Dockerfile
   if [ ! -z "$COMPONENT" -a ! -z "$VERSION" ];then
      exist=`docker images | grep -w $COMPONENT | grep -w $VERSION | wc -l`
      if [ "$exist" -eq "1" ];then
          docker rmi -f $COMPONENT:$VERSION
      fi
   fi
}
function build() {
   cd $CURRENT_HOME
   docker build -t $COMPONENT:$VERSION -f $CURRENT_HOME/$COMPONENT/Dockerfile .
   cd -
}

function clean() {
   cd $CURRENT_HOME
   if [ -d "$COMPONENT" ];then
       rm -rf $COMPONENT
   fi
}

function main() {
   echo "========== start build image $COMPONENT =========="
   init
   build
   clean
   echo "========== finish build image $COMPONENT =========="
}



####################################
#                                 #
#          EXECUTE                #
#                                 #
###################################

main
