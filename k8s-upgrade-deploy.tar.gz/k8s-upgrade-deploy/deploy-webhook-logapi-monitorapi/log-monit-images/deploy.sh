#!/bin/bash

set -ex

####################################
#                                 #
#          VARIABLES              #
#                                 #
###################################
COMPONENT=(apimysql apiresource apilog apitask apiwebhook)
TAR=(deploy-api webhook)
CURRENT_HOME=$(cd `dirname $0`; pwd)

####################################
#                                 #
#          FUNCTIONS              #
#                                 #
###################################
function init() {

    for t in ${!TAR[@]};
    do
      if [ -f "${TAR[$t]}.tar.gz" ];then
         tar -xvzf ${TAR[$t]}.tar.gz
      fi
    done

   tar -xvzf deploy-api.tar.gz
   tar -xvzf webhook.tar.gz
   if [ -d "$CURRENT_HOME/log" ];then
     rm -rf $CURRENT_HOME/log
   fi
   chmod +x $CURRENT_HOME/deploy-api.sh
   mkdir $CURRENT_HOME/log
}
function run() {   
    for com in ${!COMPONENT[@]};
    do
      nohup ./deploy-api.sh ${COMPONENT[$com]} >> $CURRENT_HOME/log/${COMPONENT[$com]}.log  &
    done
    wait

}
function clean() {
   cd $CURRENT_HOME
    for t in ${!TAR[@]};
    do
      if [ -d "$CURRENT_HOME/${TAR[$t]}" ];then
         rm -rf $CURRENT_HOME/${TAR[$t]}
      fi
    done 
}

function main() {
   init
   run
   clean
}



####################################
#                                 #
#          EXECUTE                #
#                                 #
###################################

main
