#!/bin/bash

MYSQL_IP=$1
HARBOR_IP=$2

kubectl label node $MYSQL_IP mysql=true

#sed -i "s/_HARBOR_IP/${HARBOR_IP}/g" webhook-configmap.yaml
sed -i "s/.*harbor.ip.*/      harbor.ip=${HARBOR_IP}/" ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/webhook-configmap.yaml

kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/mysql-deployment.yaml --validate=false
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/mysql-service.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/logapi-configmap.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/logapi-deployment.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/logapi-service.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/resourceapi-configmap.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/resourceapi-deployment.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/resourceapi-service.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/taskapi-demploment.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/webhook-configmap.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/webhook-deployment.yaml
kubectl create -f ~/k8s-upgrade-deploy/deploy-webhook-logapi-monitorapi/webhook-service.yaml
