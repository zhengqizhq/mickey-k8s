#!/bin/bash

####################################
#                                 #
#          VARIABLES              #
#                                 #
###################################
DNS=$1
HAPROXY_IP=$2
# six space
SPACE="      "
SEDFILE_CN='/etc/bind/db.hc'
SEDFILE_CONF_LOCAL='/etc/bind/named.conf.local'
SEDFILE_CONF_OPTIONS='/etc/bind/named.conf.options'
CURRENT_HOME=$(cd `dirname $0`; pwd)

####################################
#                                 #
#          FUNCTIONS              #
#                                 #
###################################
function init() {
  #sed -i "s/\s\+localhost/${SPACE}${DNS}/g" ${SEDFILE_CN}
  sed -i "s/harmonycloud.cn/${DNS}/g" ${SEDFILE_CN}
  sed -i "s/127.0.0.1/${HAPROXY_IP}/g" ${SEDFILE_CN}
  sed -i "/::1/a *       IN      A       ${HAPROXY_IP}" ${SEDFILE_CN}

  cat <<EOF > ${SEDFILE_CONF_LOCAL}
zone "${DNS}" {
  type master;
  file "/etc/bind/db.hc";
};
EOF

  sed -i "s/127.0.0.1/${HAPROXY_IP}/g" ${SEDFILE_CONF_OPTIONS}

}
function run() {

  /usr/bin/supervisord
}

function main() {
   init
   run
}



####################################
#                                 #
#          EXECUTE                #
#                                 #
###################################

main
