#!/bin/bash

####################################
#                                 #
#          VARIABLES              #
#                                 #
###################################
HOSTNAME=$1
HAPROXY_IP=$2
FORWARDERS_IP=$3
# six space
SPACE="      "
SEDFILE_CN='/etc/bind/db.luoy.cn'
SEDFILE_CONF_LOCAL='/etc/bind/named.conf.local'
SEDFILE_CONF_OPTIONS='/etc/bind/named.conf.options'
CURRENT_HOME=$(cd `dirname $0`; pwd)

####################################
#                                 #
#          FUNCTIONS              #
#                                 #
###################################
function init() {
  sed -i "s/\s\+localhost/${SPACE}${HOSTNAME}/g" ${SEDFILE_CN}
  sed -i "s/127.0.0.1/${HAPROXY_IP}/g" ${SEDFILE_CN}
  sed -i "/::1/a *       IN      A       ${HAPROXY_IP}" ${SEDFILE_CN}

  cat >> ${SEDFILE_CONF_LOCAL} << EOF
zone "luoy.cn" {
  type master;
  file "/etc/bind/db.luoy.cn";
};
EOF
  sed -i "s/\/\/\s\+forwarders/forwarders/" ${SEDFILE_CONF_OPTIONS}
  sed -i "s/\/\/\s\+0.0.0.0/${SPACE}${FORWARDERS_IP}/" ${SEDFILE_CONF_OPTIONS}
  sed -i "/${FORWARDERS_IP}/a };" ${SEDFILE_CONF_OPTIONS}

  # echo 'include "/etc/bind/rndc.key";' >> /etc/bind/named.conf

  # chown root:bind /etc/bind/rndc.key
}
function run() {   
  sudo service bind9 restart
}

function main() {
   init
}



####################################
#                                 #
#          EXECUTE                #
#                                 #
###################################

main
