#!/bin/bash

DNS_DOMAIN=$1
HAPROXY_IP=$2
BIND9_IP=$3

cp -r ~/k8s-upgrade-deploy/deploy-bind9/bind9-deployment.yaml.template ~/k8s-upgrade-deploy/deploy-bind9/bind9-deployment.yaml

sed -i "s/_DNS_DOMAIN/${DNS_DOMAIN}/g" ~/k8s-upgrade-deploy/deploy-bind9/bind9-deployment.yaml
sed -i "s/_HAPROXY_IP/${HAPROXY_IP}/g" ~/k8s-upgrade-deploy/deploy-bind9/bind9-deployment.yaml

kubectl label node $BIND9_IP bind9=true
kubectl create -f ~/k8s-upgrade-deploy/deploy-bind9/bind9-deployment.yaml
